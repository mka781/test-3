
import { useState, useEffect } from "react";
import "./App.css";

function MKAPlanner() {
  const [appointments, setAppointments] = useState([]);
  const [newAppointment, setNewAppointment] = useState("");
  const [date, setDate] = useState("");
  const [status, setStatus] = useState("à faire");
  const [tag, setTag] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 1500);
    return () => clearTimeout(timer);
  }, []);

  const addAppointment = () => {
    if (newAppointment.trim() !== "") {
      setAppointments([
        ...appointments,
        {
          id: Date.now(),
          text: newAppointment,
          date: date || new Date().toISOString(),
          status,
          tag,
        },
      ]);
      setNewAppointment("");
      setDate("");
      setStatus("à faire");
      setTag("");
    }
  };

  if (loading) {
    return (
      <div className="loader">
        <img src="/logo-mka.png" alt="MKA Logo" className="logo" />
        <p>Chargement de MKA PLANNER...</p>
      </div>
    );
  }

  return (
    <div className="container">
      <h1>MKA PLANNER</h1>
      <div className="form">
        <textarea placeholder="RDV..." value={newAppointment} onChange={(e) => setNewAppointment(e.target.value)} />
        <input type="datetime-local" value={date} onChange={(e) => setDate(e.target.value)} />
        <select value={status} onChange={(e) => setStatus(e.target.value)}>
          <option value="à faire">À faire</option>
          <option value="en cours">En cours</option>
          <option value="terminé">Terminé</option>
        </select>
        <input placeholder="Tag..." value={tag} onChange={(e) => setTag(e.target.value)} />
        <button onClick={addAppointment}>Ajouter</button>
      </div>
      <div className="appointments">
        {appointments.map((appt) => (
          <div key={appt.id} className="card">
            <h3>{appt.text}</h3>
            <p>📅 {new Date(appt.date).toLocaleString()}</p>
            <p>📝 Statut : {appt.status}</p>
            <p>🏷️ Tag : {appt.tag}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default MKAPlanner;
